package automation.cucumberverizon;
import org.junit.runner.RunWith;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features",
glue="stepDefinitions",
//stepNotifications=true,
tags="@seleniumTest"

)
public class TestRunner extends AbstractTestNGCucumberTests  {

}