package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PaymentDefinition {
	@Given("user already has an account on gpay")
	public void user_already_has_an_account_on_gpay() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("given");
	}
	@When("userid is correct")
	public void userid_is_correct() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("when");
	}
	@Then("gpay message should be sent")
	public void gpay_message_should_be_sent() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("then");
	}
	@Given("user already has an account on Phonepe")
	public void user_already_has_an_account_on_phonepe() {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("given pp");
	}
	@Then("phonePe message should be sent")
	public void phone_pe_message_should_be_sent() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("then pp");
	}

}
