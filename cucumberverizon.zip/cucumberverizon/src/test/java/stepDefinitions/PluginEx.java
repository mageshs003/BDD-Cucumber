package stepDefinitions;

public class PluginEx {

}
