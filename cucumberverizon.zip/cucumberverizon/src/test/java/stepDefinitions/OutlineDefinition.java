package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OutlineDefinition {
	@Given("User is on the login screen outline")
	public void user_is_on_the_login_screen_outline() {
	// Write code here that turns the phrase above into concrete actions
	throw new io.cucumber.java.PendingException();
	}

	@When("user provides correct username outline\"userA\"")
	public void user_provides_correct_username_outline_user_a() {
    // Write code here that turns the phrase above into concrete actions
	throw new io.cucumber.java.PendingException();
	}

	@When("user provides correct password outline\"passA\"")
	public void user_provides_correct_password_outline_pass_a() {
	// Write code here that turns the phrase above into concrete actions
	throw new io.cucumber.java.PendingException();

	}

	@Then("User must login")
	public void user_must_login() {
    // Write code here that turns the phrase above into concrete actions
	throw new io.cucumber.java.PendingException();
	}



}
